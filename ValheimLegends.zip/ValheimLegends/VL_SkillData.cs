namespace ValheimLegends;

public class VL_SkillData
{
	public int level = 0;

	public float accumulator = 0f;

	public int max_level = 100;
}
